/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package generalmaintenance;

import java.sql.Date;

/**
 *
 * @author Xiaotao Qiu
 */
public class Client {
    private int ClientID;
    private String FirstName;
    private String LastName;
    private String Phone; 
    private String Address;
    private Date StartDate;
    private Date EndDate;
    private Boolean Active;
    private String Email;
    private Date CreatedDate;
    private Date LastUpdate;
    //private byte[] picture;
    
    public Client(int ClientID, String FirstName, String LastName, String Phone, String Address, Date StartDate, Date EndDate, Boolean Active, String Email, Date CreatedDate, Date LastUpdate)
    {
        this.ClientID = ClientID;
        this.FirstName = FirstName;
        this.LastName = LastName;
        this.Phone = Phone;
        this.Address = Address;
        this.StartDate = StartDate;
        this.EndDate = EndDate;
        this.Active = Active;
        this.Email = Email;
        this.CreatedDate = CreatedDate;
        this.LastUpdate = LastUpdate;
    }

    public int getClientID() {
        return ClientID;
    }

    public void setClientID(int ClientID) {
        this.ClientID = ClientID;
    }

    public String getFirstName() {
        return FirstName;
    }

    public void setFirstName(String FirstName) {
        this.FirstName = FirstName;
    }

    public String getLastName() {
        return LastName;
    }

    public void setLastName(String LastName) {
        this.LastName = LastName;
    }

    public String getPhone() {
        return Phone;
    }

    public void setPhone(String Phone) {
        this.Phone = Phone;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String Address) {
        this.Address = Address;
    }

    public Date getStartDate() {
        return StartDate;
    }

    public void setStartDate(Date StartDate) {
        this.StartDate = StartDate;
    }

    public Date getEndDate() {
        return EndDate;
    }

    public void setEndDate(Date EndDate) {
        this.EndDate = EndDate;
    }

    public Boolean getActive() {
        return Active;
    }

    public void setActive(Boolean Active) {
        this.Active = Active;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public Date getCreatedDate() {
        return CreatedDate;
    }

    public void setCreatedDate(Date CreatedDate) {
        this.CreatedDate = CreatedDate;
    }

    public Date getLastUpdate() {
        return LastUpdate;
    }

    public void setLastUpdate(Date LastUpdate) {
        this.LastUpdate = LastUpdate;
    }
    
//    public byte[] getImage()
//    {
//        return picture;
//    }

    @Override
    public String toString() {
        return "Client{" + "ClientID=" + ClientID + ", FirstName=" + FirstName + ", LastName=" + LastName + ", Phone=" + Phone + ", Address=" + Address + ", StartDate=" + StartDate + ", EndDate=" + EndDate + ", Active=" + Active + ", Email=" + Email + ", CreatedDate=" + CreatedDate + ", LastUpdate=" + LastUpdate + '}';
    }
    
    
}
